BACKEND COMMANDS

Filtering: `pip install django-filter==2.0` must install
Start server: `manage.py runserver`
Migrate: `manage.py migrate`
Start Migrations: `manage.py makemigrations`
In case of database re migrate: `manage.py migrate --run-syncdb`

FRONTEND
Install dependencies: `npm install`
Run server: `npm run`
open on port `localhost:3000`
