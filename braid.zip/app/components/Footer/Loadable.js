/**
 *
 * Asynchronously loads the component for Footer
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
