// import { fromJS } from 'immutable';
// import { selectHomeDomain } from '../selectors';

describe('selectHomeDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
