// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import { Home } from '../index';

describe('<Home />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
