// import { fromJS } from 'immutable';
// import { selectAddNewsDomain } from '../selectors';

describe('selectAddNewsDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
