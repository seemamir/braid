/**
 * Test sagas
 */

/* eslint-disable redux-saga/yield-effects */
// import { take, call, put, select } from 'redux-saga/effects';
// import addNewsSaga from '../saga';

// const generator = addNewsSaga();

describe('addNewsSaga Saga', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
