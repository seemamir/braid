/*
 *
 * AddNews constants
 *
 */

export const DEFAULT_ACTION = 'app/AddNews/DEFAULT_ACTION';
export const ADD_POST = 'app/AddNews/ADD_POST';
export const SET_RESPONSE = 'app/AddNews/SET_RESPONSE';
