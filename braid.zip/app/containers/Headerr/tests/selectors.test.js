// import { fromJS } from 'immutable';
// import { selectHeaderrDomain } from '../selectors';

describe('selectHeaderrDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
