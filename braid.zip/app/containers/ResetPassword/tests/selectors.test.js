// import { fromJS } from 'immutable';
// import { selectResetPasswordDomain } from '../selectors';

describe('selectResetPasswordDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
