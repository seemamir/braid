/*
 *
 * ResetPassword constants
 *
 */

export const DEFAULT_ACTION = 'app/ResetPassword/DEFAULT_ACTION';
