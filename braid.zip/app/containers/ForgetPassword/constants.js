/*
 *
 * ForgetPassword constants
 *
 */

export const DEFAULT_ACTION = 'app/ForgetPassword/DEFAULT_ACTION';
