// import { fromJS } from 'immutable';
// import { selectSignupDomain } from '../selectors';

describe('selectSignupDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
