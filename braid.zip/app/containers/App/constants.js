export const LOGGED_IN_USER = 'BRAID/App/LOGGED_IN_USER';
export const SET_EMAIL = 'BRAID/App/SET_EMAIL';
export const LOGOUT_USER = 'BRAID/App/LOGOUT_USER';
