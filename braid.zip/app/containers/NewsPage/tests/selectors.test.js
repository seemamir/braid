// import { fromJS } from 'immutable';
// import { selectNewsPageDomain } from '../selectors';

describe('selectNewsPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
