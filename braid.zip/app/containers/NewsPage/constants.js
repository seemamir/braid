/*
 *
 * NewsPage constants
 *
 */

export const DEFAULT_ACTION = 'app/NewsPage/DEFAULT_ACTION';
export const FETCH_POSTS = 'app/NewsPage/FETCH_POSTS';
export const SET_POSTS = 'app/NewsPage/SET_POSTS';
export const SET_RESPONSE = 'app/NewsPage/SET_RESPONSE';
export const UNMOUNT_REDUX = 'app/NewsPage/UNMOUNT_REDUX';
