/*
 *
 * ViewNews constants
 *
 */

export const DEFAULT_ACTION = 'app/ViewNews/DEFAULT_ACTION';
export const VIEW_POST = 'app/ViewNews/VIEW_POST';
export const FETCH_POST_COMMENTS = 'app/ViewNews/FETCH_POST_COMMENTS';
export const SET_POST_COMMENTS = 'app/ViewNews/FETCH_POST_COMMENTS';
export const COMMENT_ON_POST = 'app/ViewNews/COMMENT_ON_POST';
export const SET_POST = 'app/ViewNews/SET_POST';
export const UPDATE_POST = 'app/ViewNews/UPDATE_POST';
export const UNMOUNT_REDUX = 'app/ViewNews/UNMOUNT_REDUX';
